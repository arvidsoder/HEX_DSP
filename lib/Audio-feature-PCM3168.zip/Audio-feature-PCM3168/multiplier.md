multiplier 140411
	Multiplies two input waveforms, from channels zero and one.